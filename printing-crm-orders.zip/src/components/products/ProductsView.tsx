import React from 'react';
import { ProductsViewUnified } from './ProductsViewUnified';

export const ProductsView: React.FC = () => {
  return <ProductsViewUnified />;
};