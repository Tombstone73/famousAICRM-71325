import React from 'react';
import CompanyDetailsView from '@/components/details/CompanyDetailsView';

const CompanyDetails: React.FC = () => {
  return <CompanyDetailsView />;
};

export default CompanyDetails;