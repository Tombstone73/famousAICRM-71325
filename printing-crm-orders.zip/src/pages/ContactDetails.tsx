import React from 'react';
import ContactDetailsView from '@/components/details/ContactDetailsView';

const ContactDetails: React.FC = () => {
  return <ContactDetailsView />;
};

export default ContactDetails;