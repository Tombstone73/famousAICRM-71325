import React from 'react';
import { ProductAuditReport } from '@/components/products/ProductAuditReport';

export const ProductAudit: React.FC = () => {
  return <ProductAuditReport />;
};